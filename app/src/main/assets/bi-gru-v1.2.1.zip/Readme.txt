LIBRARY              | INSTALLED       | STATUS    
--------------------------------------------------
tensorflow           | 2.17.0
keras-tuner          | 1.4.8
mediapipe            | 0.10.14        
opencv-python        | 4.11.0.86      
numpy                | 1.26.4
pandas               | 3.0.0
scikit-learn         | 1.8.0
tqdm                 | 4.67.3
matplotlib           | 3.10.8
--------------------------------------------------
Python               | 3.11.0
--------------------------------------------------
{
    "0": "anxiety",
    "1": "fever",
    "2": "feverish",
    "3": "insomnia",
    "4": "itching",
    "5": "no_action",
    "6": "pain",
    "7": "polyuria",
    "8": "suffocated",
    "9": "wounded"
} Blue
